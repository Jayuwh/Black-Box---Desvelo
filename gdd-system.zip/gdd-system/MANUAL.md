# SIETE NOCHES — manual de uso

Guía práctica para usar el sistema: cómo abrirlo, editar el GDD, configurar variables, efectos, fondo y sonido, y publicar los cambios.

## Empezar

Para editar con guardado en los archivos reales hace falta Node.js (el sistema corre sobre un pequeño servidor local).

```sh
npm start
# o: node server.js
```

Andá a `http://localhost:3000`.

- **`http://localhost:3000/`** — el visor: el documento renderizado, listo para leer o compartir.
- **`http://localhost:3000/editor.html`** — el editor, protegido por contraseña.

> Sin servidor (abriendo los `.html` con doble clic) se puede leer el contenido, pero el botón *Guardar* no podrá escribir en los archivos (no hay copia local de respaldo). Para editar con guardado real usá `npm start`.

## Entrar al editor

Al abrir `editor.html` aparece una pantalla de acceso. La contraseña por defecto es **`Admin091`**. Al acertarla se cargan los tres paneles del editor.

Para cambiar la contraseña, reemplazá el hash SHA-256 en `js/auth.js` (calculá el hash de la nueva contraseña y ponelo en `hashContrasena`).

## El editor: tres paneles

- **Izquierda — Variables:** define los nombres que cambian en el documento (protagonista, evento, etc.) y sus colores y efectos.
- **Centro — Editor:** el texto en markdown, con barra de herramientas arriba.
- **Derecha — Vista previa:** el documento renderizado, actualizado en vivo mientras escribís.

## Variables

Una variable es una etiqueta `[CLAVE]` que se escribe en el texto y se reemplaza por un valor con color y efecto.

1. En el panel izquierdo pulsá **+ Nueva variable** y escribí la clave (mayúsculas, sin espacios, ej. `NP`).
2. Configurala:
   - **Texto que reemplaza a la variable:** qué se ve en lugar de `[NP]`.
   - **Color:** color del texto.
   - **Efecto:** el estilo visual.
   - Si el efecto es *Degradado*, aparece un segundo selector **Color degradado** y una barra que muestra el resultado de los dos colores.
3. Escribí `[NP]` donde quieras usarla en el documento. Al cambiar la variable, todas sus apariciones se actualizan al instante.

Las variables vienen precargadas (`[NP]`, `[VOZ]`, `[EVENTO]`, `[TITULO]`) y se guardan junto con el documento.

## Efectos de texto

Disponibles para variables y para fragmentos ad-hoc. Ad-hoc se escriben en línea: `{{efecto:texto}}`.

| Efecto | Variable | Ad-hoc |
|---|---|---|
| Ninguno | `none` | — |
| Neón / resplandor | `glow` | `{{glow:texto}}` |
| Degradado de dos colores | `gradient` | `{{gradient:texto}}` |
| Parpadeo | `flicker` | `{{flicker:texto}}` |
| Subrayado ondulado | `underline` | `{{underline:texto}}` |
| Contorno | `contorno` | `{{contorno:texto}}` |
| Sombra | `sombra` | `{{sombra:texto}}` |
| Marcado | `marca` | `{{marca:texto}}` |
| Onda | `onda` | `{{onda:texto}}` |
| Arcoíris | `arcoiris` | `{{arcoiris:texto}}` |
| Temblor | `temblor` | `{{temblor:texto}}` |

## Separadores temáticos

En su propia línea (solas), insertan un separador decorativo:

```
***void***
***shame***
***fracture***
```

## Barra de herramientas

- **Separador · void / shame / fracture:** insertan los separadores.
- **Envolver: …:** aplican el efecto al texto seleccionado.
- **Guardar:** guarda todo (texto, variables y ajustes).
- **Exportar .md / Exportar variables:** descargan los archivos.
- **Importar .md:** carga un archivo de texto al editor.

## Guardar

El botón **Guardar** persiste los cambios (texto, variables y ajustes) usando, en orden:

1. **En línea (Supabase):** si configuraste las credenciales en `js/datos.js`, guarda el documento en la tabla `documento` de Supabase. Cualquier persona que abra el visor o el editor ve la última versión guardada, esté hosteado donde esté.
2. **En disco (servidor local):** si `SUPABASE_URL` está vacía, envía los cambios a `POST /api/save`, que escribe `content/gdd.md`, `content/variables.json` y `content/ajustes.json` en los archivos reales.

En la barra superior se indica qué ocurrió: "Guardado en línea", "Guardado en disco (local)" o, si no hay Supabase ni servidor activo, "Error al guardar (configurá Supabase o usá npm start)". El sistema no guarda copias en el navegador: los cambios viven en la base de datos (o en los archivos), así que al recargar cualquier página se ven reflejados.

### Activar Supabase

1. Creá un proyecto gratis en [supabase.com](https://supabase.com).
2. En el SQL Editor, ejecutá el contenido de `supabase.sql` (crea la tabla `documento` con una sola fila `id = 'documento'` y las políticas de lectura/escritura anónima).
3. Copiá `SUPABASE_URL` y `SUPABASE_ANON_KEY` (Dashboard → Settings → API) en las constantes de `js/datos.js`.
4. Subí el proyecto al hosting. Al pulsar **Guardar** en el editor se crea la fila con el documento; el visor la lee y muestra el contenido guardado.

> La primera vez, si la fila todavía no existe en la base, el visor/editor muestran el contenido por defecto de `content/` hasta que se guarde por primera vez.

## Llevar los cambios a un sitio publicado

Con Supabase activado, los cambios se guardan directamente en la nube y el sitio publicado muestra la última versión sin re-subir nada. Solo hay que subir una vez la carpeta con las credenciales ya configuradas.

Sin Supabase, un hosting estático no puede escribir archivos; para publicar los cambios:

1. En el editor pulsá **Exportar .md** (y **Exportar variables** si tocaste el panel de variables).
2. Reemplazá `content/gdd.md` y `content/variables.json` en el proyecto con los archivos exportados.
3. Volvé a subir la carpeta al hosting.

Si además cambiaste fondo/sonido, reemplazá también `content/ajustes.json`.

## Fondo y sonido

En el panel **Fondo y sonido** (abajo del panel de variables) se configura la ambientación, que se aplica al instante en el editor y también se muestra en el visor:

- **Efecto de fondo:** `niebla`, `estrellas`, `lluvia`, `pulso`, `estatico` o `ninguno`.
- **Color de fondo:** redefine el color de toda la interfaz.
- **Sonido ambiente:** `viento`, `zumbido`, `latido`, `lluvia` (se sintetiza con WebAudio, sin archivos de audio) o `sin sonido`.
- **Volumen:** nivel del sonido ambiente.

Estos ajustes se guardan con el botón **Guardar**.

## Ver el documento (visor)

En `index.html`:

- Se muestra el documento con las variables y efectos resueltos.
- Si configuraste fondo/sonido en el editor, aquí se aplican.
- El sonido no arranca solo: pulsá el botón **Sonido** (abajo a la derecha) para encenderlo o apagarlo. El primer clic desbloquea el audio del navegador.

## Llevar los cambios a un sitio publicado

Como un servicio de hosting estático (por ejemplo Netlify) no permite escribir archivos, para publicar los cambios:

1. En el editor pulsá **Exportar .md** (y **Exportar variables** si tocaste el panel de variables).
2. Reemplazá `content/gdd.md` y `content/variables.json` en el proyecto con los archivos exportados.
3. Volvé a subir la carpeta al hosting.

Si además cambiaste fondo/sonido, reemplazá también `content/ajustes.json`.
