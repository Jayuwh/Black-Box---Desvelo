# SIETE NOCHES — guía completa del sistema

Cómo funciona el proyecto de principio a fin: visor, editor, parser, servidor y tema.

## Qué es

Un sistema para redactar y mostrar un Game Design Document (GDD) en el navegador, sin frameworks ni pasos de build. Se compone de dos caras:

- **`index.html` (visor):** muestra el documento renderizado para leerlo o compartirlo.
- **`editor.html` (editor):** permite escribir el documento en markdown, configurar variables con color/efecto y ver la vista previa en vivo. Está protegido por contraseña.

## Cómo arrancarlo

```sh
npm start
# o directamente: node server.js
```

Se levanta en `http://localhost:3000`. Con el servidor activo (o con Supabase configurado), el botón **Guardar** del editor persiste los cambios.

Sin servidor ni Supabase también se puede leer: abrir los `.html` con doble clic (protocolo `file://`) sirve para ver el contenido, pero el botón Guardar fallará porque no hay a dónde escribir (no existe copia local de respaldo).

## Estructura de archivos

```
gdd-system/
├── index.html          visor del documento
├── editor.html         editor (requiere contraseña)
├── package.json        script "npm start"
├── server.js           servidor estático + endpoint /api/save (respaldo local)
├── supabase.sql        SQL de la tabla y políticas para Supabase
├── css/
│   └── theme.css       todo el diseño (tokens, tipografías, efectos)
├── js/
│   ├── parser.js       convierte markdown + sintaxis propia a HTML
│   ├── app.js          lógica del visor
│   ├── editor.js       lógica del editor
│   ├── auth.js         hash de la contraseña del editor
│   ├── datos.js        capa de persistencia (Supabase + respaldo en archivos)
│   └── fondo.js        efectos de fondo (canvas) y sonido ambiente (WebAudio)
└── content/
    ├── gdd.md          el documento por defecto
    ├── variables.json  las variables por defecto
    └── ajustes.json    los ajustes de fondo y sonido por defecto
```

## Flujo del visor (`index.html` + `js/app.js`)

Al abrir la página:

1. `js/datos.js` (`cargarDocumento()`) intenta leer la fila `id = 'documento'` de la tabla `documento` en Supabase. Si no está configurado o la fila no existe, descarga `content/gdd.md`, `content/variables.json` y `content/ajustes.json`.
2. `js/parser.js` convierte el markdown a HTML usando las variables cargadas.
3. El HTML se inyecta en `<main id="documento">` y se aplican los ajustes de fondo/sonido.

No hay copia local (`localStorage`): lo que se ve es siempre el contenido guardado (en la nube o en los archivos). Guardando desde el editor y recargando, el visor muestra los cambios al instante.

## Flujo del editor (`editor.html` + `js/editor.js` + `js/auth.js`)

1. Al entrar, se muestra una pantalla de acceso. La contraseña no se guarda en texto plano: `js/auth.js` contiene solo su hash SHA-256, y al escribir la contraseña se calcula su hash en el navegador y se compara.
2. Tras autenticarse, se carga el contenido con `cargarDocumento()` (Supabase o archivos) en tres paneles:
   - **Variables** (izquierda): lista de variables, cada una con texto de reemplazo, color y efecto.
   - **Editor** (centro): textarea de markdown con barra de herramientas.
   - **Vista previa** (derecha): el documento renderizado en vivo mientras escribís.
3. El botón **Guardar** llama a `guardarDocumento()`. Si hay Supabase configurado, hace `upsert` en la tabla `documento` (persistencia en línea); si no, envía `POST /api/save` al servidor local que escribe los archivos en disco.
   - Si no hay Supabase ni servidor activo, el guardado falla y se indica en la barra (no hay copia local de respaldo).
4. **Exportar .md / Exportar variables** descargan los archivos a tu equipo. **Importar .md** carga un archivo de texto en el editor.

### Cambiar la contraseña

1. Calculá el hash SHA-256 de la nueva contraseña (por ejemplo con `sha256sum` en terminal o cualquier herramienta online).
2. Reemplazá el valor de `hashContrasena` en `js/auth.js`.

> La verificación ocurre 100 % en el navegador: sirve como control de acceso básico, no como seguridad a prueba de todo (cualquier persona con acceso al código puede reemplazar el hash).

## Sintaxis del editor (`js/parser.js`)

El parser soporta markdown estándar y sintaxis propia:

| Sintaxis | Resultado |
|---|---|
| `# Título`, `## Título`, `### Título` | Encabezados |
| `**negrita**`, `*cursiva*`, `` `código` `` | Énfasis y código |
| `- item`, `1. item` | Listas con viñetas o numeradas |
| `> cita` | Cita |
| `[texto](https://url)` | Enlace (se abre en pestaña nueva) |
| `[CLAVE]` | Variable: la reemplaza por su valor, color y efecto definidos en el panel |
| `{{glow:texto}}`, `{{gradient:texto}}`, `{{flicker:texto}}`, `{{underline:texto}}`, `{{contorno:texto}}`, `{{sombra:texto}}`, `{{marca:texto}}`, `{{onda:texto}}`, `{{arcoiris:texto}}`, `{{temblor:texto}}` | Efecto ad-hoc sobre un fragmento sin necesidad de crear variable |
| `***void***`, `***shame***`, `***fracture***` (en su propia línea) | Separadores temáticos |

Las variables se escriben en mayúsculas, sin espacios (`[NP]`, `[VOZ]`, `[EVENTO]`, `[TITULO]`). Cada una tiene:

- **valor:** el texto que reemplaza la etiqueta en el documento.
- **color:** el color del texto.
- **colorSecundario:** segundo color, solo para el efecto `gradient`.
- **efecto:** `none`, `glow` (neón), `gradient` (degradado de dos colores), `flicker` (parpadeo), `underline` (subrayado), `contorno`, `sombra`, `marca` (marcado), `onda`, `arcoiris` o `temblor`.

Las variables viven en `content/variables.json`. Cambiar una variable en el editor actualiza todas sus apariciones en el documento al instante. Para el efecto `gradient` se muestran dos selectores de color y una barra de previsualización del degradado en el panel.

## Fondo y sonido (`js/fondo.js`)

El panel **Fondo y sonido** del editor configura ajustes que se guardan en `content/ajustes.json` y que también aplica el visor:

- **Efecto de fondo:** `none`, `niebla`, `estrellas`, `lluvia`, `pulso` o `estatico`. Se dibujan en un `<canvas>` fijo detrás del contenido (`#lienzo-fondo`) con `requestAnimationFrame`.
- **Color de fondo:** redefine el token `--fondo-vacio` en vivo.
- **Sonido ambiente:** `viento`, `zumbido`, `latido` o `lluvia`, generados con WebAudio (osciladores, ruido blanco filtrado y envolventes). No hay archivos de audio: todo se sintetiza.
- **Volumen:** ganancia maestra del contexto de audio.

En el visor, el sonido no se autoplaya (las políticas del navegador lo impiden): un botón fijo **Sonido** lo enciende/apaga con el primer clic, que es también la interacción que desbloquea el `AudioContext`.

## La capa de persistencia (`js/datos.js`)

Es el único punto de entrada y salida de datos del sistema:

- **`cargarDocumento()`**: si `SUPABASE_URL` y `SUPABASE_ANON_KEY` están configuradas y el SDK de Supabase cargó, intenta leer la fila `id = 'documento'` de la tabla `documento`. Si no hay configuración, no hay fila, o hay un error, cae a los archivos `content/` (respaldo local). Los ajustes siempre se fusionan con `AJUSTES_POR_DEFECTO`.
- **`guardarDocumento(documento)`**: si hay Supabase, hace `upsert` de `{ id, markdown, variables, ajustes, actualizado_en }`. Si no hay configuración, devuelve `{ ok: false, motivo: 'sin-configuracion' }` y el editor cae a `POST /api/save`.

Las credenciales se pegan directamente en las constantes de `js/datos.js` (no hay variables de entorno). Están vacías por defecto, así que el proyecto funciona con el servidor local sin tocar nada.

## La base de datos en Supabase

`supabase.sql` crea la tabla `documento` y habilita Row Level Security con tres políticas (lectura, inserción y actualización anónimas):

```sql
create table if not exists public.documento (
  id text primary key,
  markdown text not null default '',
  variables jsonb not null default '{}'::jsonb,
  ajustes jsonb not null default '{}'::jsonb,
  actualizado_en timestamptz not null default now()
);
```

La única fila que usa el sistema es `id = 'documento'`; la primera vez que se pulsa **Guardar** se crea con el contenido actual. El visor cae a los archivos por defecto hasta que exista esa fila.

## El servidor (`server.js`)

Un servidor Node sin dependencias que:

1. **Sirve los archivos estáticos** (HTML, CSS, JS, contenido) desde la raíz del proyecto.
2. **Expose `POST /api/save`**: recibe `{ "markdown": "...", "variables": {...}, "ajustes": {...} }` y sobrescribe `content/gdd.md`, `content/variables.json` y `content/ajustes.json` en disco.

Queda como respaldo local para cuando no se usa Supabase. El puerto se configura con la variable de entorno `PORT` (por defecto `3000`).

## El tema (`css/theme.css`)

Todo el diseño vive en un solo archivo. Las variables CSS (tokens) están en español y se agrupan por categoría:

- **Superficies:** `--fondo-vacio`, `--fondo-superficie`, `--fondo-superficie-2`, bordes (`--borde-linea`).
- **Texto:** `--texto-principal`, `--texto-atenuado`, `--texto-tenue`.
- **Acentos:** `--acento-verguenza` (rubor/vergüenza), `--acento-aislamiento` (frío/aislamiento), `--acento-advertencia`.
- **Tipografías:** `--fuente-display`, `--fuente-cuerpo`, `--fuente-mono`.
- **Misceláneos:** `--radio` (redondeo de bordes).

Las clases de los efectos que genera el parser (`efecto-neon`, `efecto-degradado`, `efecto-parpadeo`, `efecto-subrayado`, `efecto-contorno`, `efecto-sombra`, `efecto-marca`, `efecto-onda`, `efecto-arcoiris`, `efecto-temblor`) y los separadores (`separador-vacio`, `separador-verguenza`, `separador-fractura`) se definen aquí.

## Publicar en Netlify

El proyecto es estático puro, así que se puede subir tal cual (sin build, sin variables de entorno).

- **Con Supabase configurado** (`SUPABASE_URL` y `SUPABASE_ANON_KEY` en `js/datos.js`, tabla creada con `supabase.sql`), el botón **Guardar** persiste en línea desde el sitio publicado: cualquiera que abra el visor ve la última versión.
- **Sin Supabase**, Netlify no permite escribir archivos, así que para llevar cambios al sitio publicado hay que:

1. En el editor, **Exportar .md** (y **Exportar variables** si toqué el panel).
2. Reemplazá `content/gdd.md` (y `content/variables.json`) en el proyecto.
3. Volvé a subir la carpeta a Netlify.
