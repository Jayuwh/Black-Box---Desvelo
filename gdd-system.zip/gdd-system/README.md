# SIETE NOCHES — sistema de GDD

Sistema estático (HTML + CSS + JS puro, sin build) para hostear y editar tu Game Design Document con un editor de markdown propio: variables con color/efecto configurables, efectos de texto ad-hoc y separadores temáticos.

## Estructura

```
index.html          -> visor: muestra el GDD renderizado
editor.html          -> editor: markdown + panel de variables + vista previa en vivo
css/theme.css        -> todo el diseño (paleta, tipografía, efectos)
js/parser.js          -> convierte markdown + sintaxis propia a HTML
js/app.js              -> lógica del visor
js/editor.js           -> lógica del editor
js/fondo.js            -> efectos de fondo (canvas) y sonido ambiente (WebAudio)
js/auth.js             -> hash de la contraseña del editor
js/datos.js             -> capa de persistencia: Supabase (en línea) con respaldo en archivos locales
supabase.sql            -> SQL de creación de la tabla y políticas para Supabase
server.js              -> servidor local (estático + endpoint /api/save para guardar en disco)
content/gdd.md          -> el documento por defecto (edítalo o sobrescríbelo desde el editor)
content/variables.json   -> variables por defecto ([NP], [VOZ], [EVENTO], [TITULO])
content/ajustes.json     -> ajustes de fondo y sonido por defecto
```

## Cómo funciona la edición

### En línea (Supabase, recomendado): guarda en la nube

Con Supabase configurado, el botón **Guardar** del editor persiste el documento (markdown + variables + ajustes) en la base de datos vía su API. Cualquier persona que abra `index.html` o el editor ve la última versión guardada, sin importar dónde esté hosteado el sitio. No hace falta servidor.

Pasos para activarlo:

1. Creá un proyecto gratis en [supabase.com](https://supabase.com).
2. En el SQL Editor de Supabase, pegá y ejecutá el contenido de `supabase.sql` (crea la tabla `documento` y las políticas de lectura/escritura).
3. Copiá tu `SUPABASE_URL` y `SUPABASE_ANON_KEY` (Dashboard → Settings → API) en las constantes `SUPABASE_URL` y `SUPABASE_ANON_KEY` de `js/datos.js`.
4. Subí el proyecto al hosting (Netlify, GitHub Pages, etc.). Desde el editor, pulsá **Guardar**: la primera vez crea el documento en la nube.

Mientras las credenciales de `js/datos.js` estén vacías, todo sigue funcionando con los archivos locales (modo servidor).

### Modo servidor local: guarda en los archivos reales

Si `SUPABASE_URL` está vacía, el botón **Guardar** cae al endpoint local `POST /api/save`, que escribe `content/gdd.md`, `content/variables.json` y `content/ajustes.json` en disco.

```sh
npm start          # o: node server.js
```

Andá a `http://localhost:3000/editor.html`, editá y pulsá *Guardar*: los cambios quedan en los archivos reales y se ven al recargar `index.html`.

### Sin servidor

El sistema no usa `localStorage`: sin Supabase ni servidor, abrir las páginas por doble clic (`file://`) lee el contenido de los archivos, pero **Guardar** fallará (no hay a dónde escribir). Con Supabase configurado sí se puede guardar en línea incluso abriendo los archivos directamente.

## Sintaxis del editor

- **Variables:** `[CLAVE]` — se define en el panel izquierdo (texto, color y efecto). Cambiarla actualiza todas las apariciones en el documento. El efecto *degradado* admite dos colores configurables.
- **Efectos ad-hoc** (sin variable): `{{glow:texto}}`, `{{gradient:texto}}`, `{{flicker:texto}}`, `{{underline:texto}}`, `{{contorno:texto}}`, `{{sombra:texto}}`, `{{marca:texto}}`, `{{onda:texto}}`, `{{arcoiris:texto}}`, `{{temblor:texto}}`
- **Fondo y sonido:** desde el editor se configuran el efecto de fondo (niebla, estrellas, lluvia, pulso, estático), el color de fondo y el sonido ambiente (viento, zumbido, latido, lluvia) con volumen. Se guardan en la nube (o en `content/ajustes.json` en modo servidor) y se aplican también en el visor.
- **Separadores** (en su propia línea): `***void***`, `***shame***`, `***fracture***`
- Markdown estándar: `#`, `##`, `###`, `**negrita**`, `*cursiva*`, `` `código` ``, `- listas`, `1. listas`, `> citas`, `[texto](url)`

## Desplegar en Netlify

**Opción A — arrastrar y soltar (sin cuenta de Git):**
1. Andá a [app.netlify.com/drop](https://app.netlify.com/drop)
2. Arrastrá la carpeta completa del proyecto
3. Listo — Netlify te da una URL al instante

**Opción B — desde un repositorio:**
1. Subí esta carpeta a un repo (GitHub/GitLab/Bitbucket)
2. En Netlify: *Add new site → Import an existing project*
3. Build command: dejalo vacío (no hay build)
4. Publish directory: `/` (la raíz del proyecto)
5. Deploy

No hay variables de entorno ni dependencias que instalar — es HTML/CSS/JS plano.
