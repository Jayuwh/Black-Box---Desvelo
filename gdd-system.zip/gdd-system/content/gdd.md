# [TITULO]

Game Design Document · v0.1 · documento vivo

***void***

## Ficha rápida

- **Género:** narrativo · puzles · decisiones
- **Perspectiva:** [VOZ] guía a [NP] — no lo controla
- **Duración de la partida:** 7 días / 7 noches (ciclo cerrado)
- **Tono:** íntimo, incómodo, contenido. Nunca explicativo de más.
- **Plataforma objetivo:** PC / móvil (sesiones cortas, formato diario)

***void***

## Sinopsis

Faltan siete días para [EVENTO]. Para cualquier otra persona sería solo una fecha en el calendario. Para [NP], es el punto de quiebre de todo lo que ha evitado sentir y enfrentar.

Durante el día, [NP] transita su rutina — el trabajo, la escuela, salidas simples — que cargan una vergüenza capaz de condicionar cada decisión, por pequeña que sea. Durante la noche, esa vergüenza toma forma en sueños recurrentes: recuerdos deformados de un evento pasado que nunca se explica del todo, pero que regresa una y otra vez, cada vez con mayor claridad.

El jugador ayuda a [NP] a sobrevivir ambos mundos, sabiendo que uno alimenta al otro. {{gradient:Lo que se evita de día regresa de noche. Lo que se enfrenta de noche, se refleja al despertar.}}

> No hay forma de eliminar por completo la vergüenza. La meta no es que desaparezca, sino que [NP] pueda presentarse sintiéndola, sin dejar que decida por él.

***shame***

## Premisa

Un juego narrativo de puzles y decisiones que sigue los últimos siete días antes de un evento crucial en la vida de [NP]: [EVENTO], que ha estado evitando enfrentar durante meses.

El jugador no controla a [NP] de forma directa. En su lugar, asume el rol de [VOZ] — una presencia interna que solo [NP] puede percibir, encargada de guiarlo, aconsejarlo y acompañarlo a través de sus decisiones diarias.

Esta dinámica rompe deliberadamente la cuarta pared: [NP] es consciente de [VOZ], la cuestiona, confía en ella y, eventualmente, deberá aprender a actuar sin depender por completo de ella.

***void***

## Pilares de diseño

1. **La vergüenza no se cura, se administra.** Ningún sistema del juego apunta a "vaciar" una barra. Apuntan a que [NP] actúe *a pesar* de ella.
2. **El día y la noche son el mismo problema visto dos veces.** Todo lo evitado de día tiene una versión distorsionada de noche. Todo lo resuelto de noche dialoga con la vigilia.
3. **[VOZ] debe volverse prescindible.** El arco mecánico del juego es la reducción progresiva de la dependencia del jugador sobre [NP], no al revés.
4. **Nada se explica del todo.** El evento original que originó la vergüenza se sugiere, se fragmenta, se repite — nunca se declara en una sola escena.

***void***

## El bucle de siete días

Cada jornada se estructura en dos mitades jugables, unidas por un mismo medidor.

### Día — mundo real

[NP] atraviesa 3–4 micro-escenas cotidianas (ir al trabajo, cruzar un pasillo, responder un mensaje, hablar con alguien cercano). En cada una, el jugador — como [VOZ] — puede:

- **Susurrar una salida:** sugerir evitar la situación. Reduce la tensión inmediata, pero *carga* el sueño de esa noche.
- **Sostener:** acompañar a [NP] a través del malestar sin evitarlo. Sube la tensión visible en el momento, pero *descarga* el sueño de esa noche y desbloquea fragmentos de memoria.
- **Callar:** no intervenir. [NP] decide solo — a veces mejor, a veces peor. Es la única acción que reduce la dependencia hacia [VOZ].

### Noche — mundo onírico

El sueño de esa noche se construye con los fragmentos cargados durante el día: espacios reconocibles pero mal ensamblados (el aula con las paredes del trabajo, una voz familiar con la cara equivocada). Aquí el jugador resuelve **puzles de percepción**: reordenar un recuerdo, sostener la mirada sobre algo que el sueño intenta ocultar, nombrar lo que [NP] no puede nombrar despierto.

Cada noche resuelta con éxito **revela** un fragmento real del evento original. Cada noche evadida lo **vuelve a enterrar**, con una capa nueva de distorsión.

***fracture***

## Sistema de vergüenza

Un único medidor doble, no un contador de "puntos malos":

| Eje | Sube cuando... | Efecto |
|---|---|---|
| **Carga** | [NP] evita, [VOZ] susurra salidas | Sueños más largos, más distorsionados, más difíciles de leer |
| **Presencia** | [NP] sostiene, enfrenta, permanece | Se desbloquean fragmentos de memoria; el día siguiente ofrece nuevas variantes de diálogo |

No existe combinación que lleve Carga a cero. El juego está diseñado para que la vergüenza **persista como textura de fondo** durante las siete jornadas — lo que cambia es cuánto espacio ocupa en la conducta de [NP].

***void***

## [VOZ]: mecánica de cuarta pared

[VOZ] no es un narrador omnisciente ni un tutorial disfrazado: es un personaje que [NP] oye, cuestiona y, a partir de la mitad del juego, empieza a poner en duda en voz alta.

- **Días 1–2:** [NP] obedece casi cualquier sugerencia de [VOZ] sin resistencia.
- **Días 3–5:** aparecen líneas de diálogo donde [NP] pregunta directamente *"¿por qué me estás diciendo esto?"* — el jugador puede responder, y esa respuesta se vuelve canon.
- **Días 6–7:** el juego empieza a **restringir** las intervenciones de [VOZ] — menos opciones de "susurrar", más momentos donde solo queda "sostener" o "callar". Mecánicamente, esto fuerza la autonomía de [NP] justo cuando el jugador querría más control.

El final no premia a quien más usó a [VOZ]: premia el equilibrio entre acompañar y soltar.

***shame***

## Estructura narrativa — los siete días

1. **Día 1 — Rutina.** Se establece la normalidad y el primer indicio de evitación.
2. **Día 2 — Grieta.** Una situación cotidiana obliga a una primera decisión real.
3. **Día 3 — Pregunta.** [NP] cuestiona a [VOZ] por primera vez.
4. **Día 4 — Espejo.** El sueño empieza a citar directamente escenas del día, sin disfraz.
5. **Día 5 — Aislamiento.** Punto más bajo: quienes rodean a [NP] notan la distancia que ha puesto entre ellos.
6. **Día 6 — Fragmento completo.** El evento original se revela casi por completo, según cuánta Presencia se acumuló.
7. **Día 7 — [EVENTO].** No hay sueño esa noche. Solo la mañana, [NP], y lo que el jugador construyó con él.

***void***

## Dirección de arte

- **Día:** paleta desaturada, casi monocroma, con un único acento cálido (el rubor de la vergüenza) que crece en intensidad según la Carga acumulada.
- **Noche:** espacios familiares reconstruidos con proporciones ligeramente erróneas; niebla como mecánica visual literal — la memoria "emerge" del blur, nunca aparece nítida de golpe.
- **[VOZ]:** sin representación visual. Solo texto y un halo de color frío en los bordes de la pantalla cuando interviene.

## Dirección de sonido

- Silencio como recurso principal durante el día — los sonidos ambientes se **amortiguan** cuando sube la Carga, simulando disociación.
- De noche, capas de audio reconocibles pero fuera de sincronía (una voz que dice lo correcto un instante tarde).

***void***

## Alcance de la vertical slice

- 1 día completo + 1 noche completa, jugables de principio a fin.
- Las tres acciones de [VOZ] (susurrar / sostener / callar) implementadas con variación de diálogo real, no placeholder.
- Un puzle de sueño representativo del sistema de fragmentos.

***fracture***

*Este documento se edita en vivo desde el panel de variables. Cambiar `[NP]`, `[VOZ]`, `[EVENTO]` o `[TITULO]` actualiza todo el documento sin tocar el texto.*
