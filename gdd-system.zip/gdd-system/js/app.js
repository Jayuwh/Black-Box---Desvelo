async function renderizarDocumento() {
  const doc = await cargarDocumento();
  document.getElementById('documento').innerHTML = parsearMarkdown(doc.markdown, doc.variables);
  aplicarAjustes(doc.ajustes, false);

  const npVar = doc.variables && doc.variables.NP;
  inicializarRompecabezas(document.getElementById('documento'), npVar ? npVar.valor.charAt(0) : 'A');

  const botonSonido = document.getElementById('boton-sonido');
  botonSonido.addEventListener('click', () => {
    const encendido = botonSonido.classList.toggle('activo');
    if (encendido) iniciarSonido();
    else detenerSonido();
  });
}

renderizarDocumento();
