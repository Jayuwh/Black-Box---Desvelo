const AUTENTICACION = {
  hashContrasena: 'be5b80fb20a889e24148b200d579423acf4c09106eca0f2693ee2ed5832448c4'
};
