const SUPABASE_URL = 'https://drdjvesvgnxmetmafmqd.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_6qWmD6L0s8YvHXtiO6apUA_tIn0-Cic';
const ID_DOCUMENTO = 'documento';

let clienteSupabase = null;

function supabaseConfigurado() {
  return SUPABASE_URL.startsWith('https://') && SUPABASE_ANON_KEY.length > 20;
}

async function obtenerClienteSupabase() {
  if (clienteSupabase) return clienteSupabase;
  if (supabaseConfigurado() && window.supabase) {
    clienteSupabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  }
  return clienteSupabase;
}

async function cargarDocumento() {
  const cliente = await obtenerClienteSupabase();
  if (cliente) {
    const { data, error } = await cliente
      .from('documento')
      .select('markdown, variables, ajustes')
      .eq('id', ID_DOCUMENTO)
      .maybeSingle();
    if (!error && data) {
      return {
        markdown: data.markdown,
        variables: (data.variables && typeof data.variables === 'object') ? data.variables : {},
        ajustes: Object.assign({}, AJUSTES_POR_DEFECTO, data.ajustes || {})
      };
    }
  }

  const [md, vars] = await Promise.all([
    (await fetch('content/gdd.md')).text(),
    (await fetch('content/variables.json')).json()
  ]);
  let ajustes = {};
  try {
    ajustes = await (await fetch('content/ajustes.json')).json();
  } catch (error) {}
  return {
    markdown: md,
    variables: vars || {},
    ajustes: Object.assign({}, AJUSTES_POR_DEFECTO, ajustes)
  };
}

async function guardarDocumento(documento) {
  const cliente = await obtenerClienteSupabase();
  if (!cliente) return { ok: false, motivo: 'sin-configuracion' };
  const { error } = await cliente
    .from('documento')
    .upsert({
      id: ID_DOCUMENTO,
      markdown: documento.markdown,
      variables: documento.variables,
      ajustes: documento.ajustes,
      actualizado_en: new Date().toISOString()
    });
  if (error) return { ok: false, motivo: 'error-supabase' };
  return { ok: true };
}
