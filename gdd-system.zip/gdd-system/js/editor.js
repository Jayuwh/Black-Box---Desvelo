let variables = {};
let markdown = '';
let ajustes = Object.assign({}, AJUSTES_POR_DEFECTO);

const $ = (selector) => document.querySelector(selector);
const entrada = $('#entrada-markdown');
const vistaPrevia = $('#vista-previa-documento');
const listaVariables = $('#lista-variables');
const elementoEstado = $('#estado-guardado');

async function inicializar() {
  const doc = await cargarDocumento();
  markdown = doc.markdown;
  variables = doc.variables;
  ajustes = doc.ajustes;

  entrada.value = markdown;
  sincronizarPanelAjustes();
  renderizarListaVariables();
  actualizar();
  aplicarAjustes(ajustes, true);
}

function actualizar() {
  markdown = entrada.value;
  vistaPrevia.innerHTML = parsearMarkdown(markdown, variables);
}

async function guardar() {
  elementoEstado.textContent = 'Guardando…';
  const resultado = await guardarDocumento({ markdown, variables, ajustes });
  if (resultado.ok) {
    elementoEstado.textContent = 'Guardado en línea ' + new Date().toLocaleTimeString();
  } else if (resultado.motivo === 'sin-configuracion') {
    try {
      const respuesta = await fetch('/api/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ markdown, variables, ajustes })
      });
      if (!respuesta.ok) throw new Error('HTTP ' + respuesta.status);
      elementoEstado.textContent = 'Guardado en disco (local) ' + new Date().toLocaleTimeString();
    } catch (error) {
      elementoEstado.textContent = 'Error al guardar (configurá Supabase o usá npm start)';
    }
  } else {
    elementoEstado.textContent = 'Error al guardar en la base de datos';
  }
  setTimeout(() => { elementoEstado.textContent = ''; }, 4000);
}

function sincronizarPanelAjustes() {
  $('#ajuste-fondo').value = ajustes.efectoFondo;
  $('#ajuste-color-fondo').value = ajustes.colorFondo;
  $('#ajuste-sonido').value = ajustes.sonido;
  $('#ajuste-volumen').value = ajustes.volumen;
  $('#ajuste-titulo').value = ajustes.tituloPagina;
}

function renderizarListaVariables() {
  listaVariables.innerHTML = '';
  Object.entries(variables).forEach(([clave, v]) => {
    listaVariables.appendChild(crearElementoVariable(clave, v));
  });
}

function actualizarGradiente(clave, v, contenedor) {
  const esGradiente = v.efecto === 'gradient';
  const campoSecundario = contenedor.querySelector('.campo-color-secundario');
  const vista = contenedor.querySelector('.vista-degradado');
  if (campoSecundario) campoSecundario.hidden = !esGradiente;
  if (esGradiente) {
    const primero = v.color || '#c4456b';
    const segundo = v.colorSecundario || '#5487c9';
    vista.style.background = `linear-gradient(90deg, ${primero}, ${segundo})`;
    vista.hidden = false;
  } else if (vista) {
    vista.hidden = true;
  }
}

function crearElementoVariable(clave, v) {
  const contenedor = document.createElement('div');
  contenedor.className = 'elemento-variable';
  contenedor.innerHTML = `
    <div class="clave-variable">[${clave}]</div>
    <label>Texto que reemplaza a la variable</label>
    <input type="text" class="f-valor" value="${escaparAtributo(v.valor)}">
    <div class="fila">
      <div>
        <label>Color</label>
        <input type="color" class="f-color" value="${v.color}">
      </div>
      <div class="campo-color-secundario" hidden>
        <label>Color degradado</label>
        <input type="color" class="f-color-secundario" value="${v.colorSecundario || '#5487c9'}">
      </div>
    </div>
    <div class="vista-degradado" hidden></div>
    <div>
      <label>Efecto</label>
      <select class="f-efecto">
        <option value="none">Ninguno</option>
        <option value="glow">Neón / resplandor</option>
        <option value="gradient">Degradado (2 colores)</option>
        <option value="flicker">Parpadeo</option>
        <option value="underline">Subrayado ondulado</option>
        <option value="contorno">Contorno</option>
        <option value="sombra">Sombra</option>
        <option value="marca">Marcado</option>
        <option value="onda">Onda</option>
        <option value="arcoiris">Arcoíris</option>
        <option value="temblor">Temblor</option>
      </select>
    </div>
    <div class="acciones-variable">
      <button class="boton-insertar">Insertar [${clave}]</button>
      <button class="peligro boton-eliminar">Eliminar</button>
    </div>
  `;

  contenedor.querySelector('.f-efecto').value = v.efecto;
  actualizarGradiente(clave, v, contenedor);

  contenedor.querySelector('.f-valor').addEventListener('input', (e) => {
    variables[clave].valor = e.target.value;
    actualizar();
  });
  contenedor.querySelector('.f-color').addEventListener('input', (e) => {
    variables[clave].color = e.target.value;
    actualizarGradiente(clave, variables[clave], contenedor);
    actualizar();
  });
  contenedor.querySelector('.f-color-secundario').addEventListener('input', (e) => {
    variables[clave].colorSecundario = e.target.value;
    actualizarGradiente(clave, variables[clave], contenedor);
    actualizar();
  });
  contenedor.querySelector('.f-efecto').addEventListener('change', (e) => {
    variables[clave].efecto = e.target.value;
    actualizarGradiente(clave, variables[clave], contenedor);
    actualizar();
  });
  contenedor.querySelector('.boton-insertar').addEventListener('click', () => {
    insertarEnCursor(`[${clave}]`);
  });
  contenedor.querySelector('.boton-eliminar').addEventListener('click', () => {
    if (confirm(`¿Eliminar la variable [${clave}]? Las apariciones en el texto quedarán sin definir.`)) {
      delete variables[clave];
      renderizarListaVariables();
      actualizar();
    }
  });

  return contenedor;
}

function escaparAtributo(texto) {
  return texto.replace(/"/g, '&quot;');
}

function insertarEnCursor(texto) {
  const inicio = entrada.selectionStart;
  const fin = entrada.selectionEnd;
  entrada.value = entrada.value.slice(0, inicio) + texto + entrada.value.slice(fin);
  entrada.focus();
  entrada.selectionStart = entrada.selectionEnd = inicio + texto.length;
  actualizar();
}

$('#boton-agregar-variable').addEventListener('click', () => {
  const clave = prompt('Clave de la variable (mayúsculas, sin espacios, ej. NP):');
  if (!clave) return;
  const limpia = clave.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_');
  if (!limpia || variables[limpia]) { alert('Clave inválida o ya existente.'); return; }
  variables[limpia] = { valor: 'texto', color: '#c4456b', colorSecundario: '#5487c9', efecto: 'none' };
  renderizarListaVariables();
  actualizar();
});

entrada.addEventListener('input', actualizar);
$('#boton-guardar').addEventListener('click', guardar);

$('#boton-exportar').addEventListener('click', () => {
  const blob = new Blob([markdown], { type: 'text/markdown' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'gdd.md';
  a.click();
});

$('#boton-exportar-variables').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(variables, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'variables.json';
  a.click();
});

$('#entrada-importar').addEventListener('change', (e) => {
  const archivo = e.target.files[0];
  if (!archivo) return;
  const lector = new FileReader();
  lector.onload = () => {
    entrada.value = lector.result;
    actualizar();
  };
  lector.readAsText(archivo);
});

$('#ajuste-fondo').addEventListener('change', (e) => {
  ajustes.efectoFondo = e.target.value;
  aplicarAjustes(ajustes, false);
});
$('#ajuste-color-fondo').addEventListener('input', (e) => {
  ajustes.colorFondo = e.target.value;
  aplicarAjustes(ajustes, false);
});
$('#ajuste-sonido').addEventListener('change', (e) => {
  ajustes.sonido = e.target.value;
  aplicarAjustes(ajustes, true);
});
$('#ajuste-volumen').addEventListener('input', (e) => {
  ajustes.volumen = parseFloat(e.target.value);
  cambiarVolumen();
});
$('#ajuste-titulo').addEventListener('input', (e) => {
  ajustes.tituloPagina = e.target.value;
  document.title = ajustes.tituloPagina;
});

document.querySelectorAll('[data-insert]').forEach((boton) => {
  boton.addEventListener('click', () => insertarEnCursor(boton.dataset.insert));
});

document.querySelectorAll('[data-wrap]').forEach((boton) => {
  boton.addEventListener('click', () => {
    const efecto = boton.dataset.wrap;
    const inicio = entrada.selectionStart;
    const fin = entrada.selectionEnd;
    const seleccionado = entrada.value.slice(inicio, fin) || 'texto';
    const envuelto = `{{${efecto}:${seleccionado}}}`;
    entrada.value = entrada.value.slice(0, inicio) + envuelto + entrada.value.slice(fin);
    actualizar();
  });
});

async function sha256(texto) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(texto));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function intentarAcceso() {
  const contrasena = $('#entrada-contrasena').value;
  const hash = await sha256(contrasena);
  if (hash === AUTENTICACION.hashContrasena) {
    $('#pantalla-acceso').remove();
    $('#contenedor-editor').hidden = false;
    $('#entrada-markdown').focus();
    inicializar();
  } else {
    $('#error-acceso').textContent = 'Contraseña incorrecta.';
    $('#entrada-contrasena').value = '';
    $('#entrada-contrasena').focus();
  }
}

$('#boton-entrar').addEventListener('click', intentarAcceso);
$('#entrada-contrasena').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') intentarAcceso();
});
