const AJUSTES_POR_DEFECTO = {
  efectoFondo: 'none',
  colorFondo: '#0a0910',
  sonido: 'none',
  volumen: 0.3,
  tituloPagina: 'SIETE NOCHES — GDD'
};

const LIENZO_FONDO = document.createElement('canvas');
LIENZO_FONDO.id = 'lienzo-fondo';
document.body.appendChild(LIENZO_FONDO);

let ctxFondo = null;
let animacionFondo = null;
let ajustesActuales = null;
let particulas = [];
let audioContexto = null;
let gananciaMaestra = null;
let nodosAudio = [];
let intervalosAudio = [];

function colorARgba(hex, alfa) {
  const h = hex.replace('#', '');
  const bigint = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  const r = (bigint >> 16) & 255, g = (bigint >> 8) & 255, b = bigint & 255;
  return `rgba(${r}, ${g}, ${b}, ${alfa})`;
}

function leerVariableCss(nombre) {
  return getComputedStyle(document.documentElement).getPropertyValue(nombre).trim() || '#c4456b';
}

function dimensionarLienzo() {
  const escala = window.devicePixelRatio || 1;
  LIENZO_FONDO.width = Math.floor(window.innerWidth * escala);
  LIENZO_FONDO.height = Math.floor(window.innerHeight * escala);
  ctxFondo.setTransform(escala, 0, 0, escala, 0, 0);
}

function prepararParticulas() {
  const w = window.innerWidth;
  const h = window.innerHeight;
  particulas = [];
  const n = Math.max(40, Math.floor((w * h) / 5000));
  for (let i = 0; i < n; i++) {
    particulas.push({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 1.8 + 0.5,
      v: Math.random() * 0.5 + 0.15,
      f: Math.random() * Math.PI * 2,
      largo: Math.random() * 16 + 6
    });
  }
}

function dibujarFondo(t) {
  const w = window.innerWidth;
  const h = window.innerHeight;
  const ctx = ctxFondo;
  ctx.clearRect(0, 0, w, h);
  const acentoVerguenza = leerVariableCss('--acento-verguenza');
  const acentoAislamiento = leerVariableCss('--acento-aislamiento');

  switch (ajustesActuales.efectoFondo) {
    case 'estrellas':
      ctx.fillStyle = '#ffffff';
      for (const p of particulas) {
        ctx.globalAlpha = 0.25 + 0.75 * (0.5 + 0.5 * Math.sin(t * 0.002 + p.f));
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      break;

    case 'lluvia':
      ctx.strokeStyle = 'rgba(135, 160, 205, 0.45)';
      ctx.lineWidth = 1;
      for (const p of particulas) {
        p.y += p.v * 1.7;
        p.x -= p.v * 0.35;
        if (p.y > h + 20) { p.y = -20; p.x = Math.random() * w; }
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x - p.largo * 0.3, p.y - p.largo);
        ctx.stroke();
      }
      break;

    case 'niebla':
      for (let i = 0; i < 6; i++) {
        const ancho = w + 400;
        const x = ((t * 0.012 * (i % 2 === 0 ? 1 : -0.7)) % ancho + ancho) % ancho + (i * 320) % ancho - 300;
        const y = h * (0.15 + 0.17 * i);
        const radio = w * 0.35;
        const g = ctx.createRadialGradient(x, y, 0, x, y, radio);
        const color = i % 2 === 0 ? acentoVerguenza : acentoAislamiento;
        g.addColorStop(0, colorARgba(color, 0.11));
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.fillRect(x - radio, y - radio, radio * 2, radio * 2);
      }
      break;

    case 'pulso':
      const radioPulso = h * (0.45 + 0.18 * Math.sin(t * 0.0012));
      const g = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, radioPulso);
      g.addColorStop(0, colorARgba(acentoVerguenza, 0.12));
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
      break;

    case 'estatico':
      ctx.fillStyle = '#ffffff';
      for (const p of particulas) {
        ctx.globalAlpha = Math.random() * 0.16;
        ctx.fillRect(p.x % w, p.y % h, 1.5, 1.5);
      }
      ctx.globalAlpha = 1;
      break;
  }
}

function bucleFondo(t) {
  if (!ajustesActuales || ajustesActuales.efectoFondo === 'none') return;
  dibujarFondo(t);
  animacionFondo = requestAnimationFrame(bucleFondo);
}

function aplicarAjustes(ajustes, conSonido) {
  ajustesActuales = Object.assign({}, AJUSTES_POR_DEFECTO, ajustes);
  document.documentElement.style.setProperty('--fondo-vacio', ajustesActuales.colorFondo);
  document.documentElement.style.backgroundColor = ajustesActuales.colorFondo;
  if (ajustesActuales.tituloPagina) document.title = ajustesActuales.tituloPagina;

  if (!ctxFondo) {
    ctxFondo = LIENZO_FONDO.getContext('2d');
    window.addEventListener('resize', () => {
      dimensionarLienzo();
      prepararParticulas();
    });
  }
  dimensionarLienzo();
  prepararParticulas();

  if (animacionFondo) { cancelAnimationFrame(animacionFondo); animacionFondo = null; }
  ctxFondo.clearRect(0, 0, window.innerWidth, window.innerHeight);
  if (ajustesActuales.efectoFondo !== 'none') {
    animacionFondo = requestAnimationFrame(bucleFondo);
  }

  if (conSonido) {
    if (ajustesActuales.sonido !== 'none') iniciarSonido();
    else detenerSonido();
  }
}

function crearRuidoBlanco(segundos) {
  const buffer = audioContexto.createBuffer(1, Math.floor(audioContexto.sampleRate * segundos), audioContexto.sampleRate);
  const datos = buffer.getChannelData(0);
  for (let i = 0; i < datos.length; i++) datos[i] = Math.random() * 2 - 1;
  return buffer;
}

function crearGananciaMaestra() {
  gananciaMaestra = audioContexto.createGain();
  gananciaMaestra.gain.value = (ajustesActuales && ajustesActuales.volumen) || 0.3;
  gananciaMaestra.connect(audioContexto.destination);
}

function crearViento() {
  const fuente = audioContexto.createBufferSource();
  fuente.buffer = crearRuidoBlanco(4);
  fuente.loop = true;
  const filtro = audioContexto.createBiquadFilter();
  filtro.type = 'lowpass';
  filtro.frequency.value = 420;
  const ganancia = audioContexto.createGain();
  ganancia.gain.value = 0.35;
  const lfo = audioContexto.createOscillator();
  lfo.frequency.value = 0.08;
  const lfoGanancia = audioContexto.createGain();
  lfoGanancia.gain.value = 0.18;
  lfo.connect(lfoGanancia);
  lfoGanancia.connect(ganancia.gain);
  fuente.connect(filtro);
  filtro.connect(ganancia);
  ganancia.connect(gananciaMaestra);
  fuente.start();
  lfo.start();
  nodosAudio.push(fuente, filtro, ganancia, lfo, lfoGanancia);
}

function crearZumbido() {
  [55, 55.7, 110.3].forEach((frecuencia, i) => {
    const oscilador = audioContexto.createOscillator();
    oscilador.type = i === 2 ? 'triangle' : 'sine';
    oscilador.frequency.value = frecuencia;
    const ganancia = audioContexto.createGain();
    ganancia.gain.value = i === 2 ? 0.02 : 0.09;
    oscilador.connect(ganancia);
    ganancia.connect(gananciaMaestra);
    oscilador.start();
    nodosAudio.push(oscilador, ganancia);
  });
}

function crearLatido() {
  const intervalo = setInterval(() => {
    if (!audioContexto) return;
    const ahora = audioContexto.currentTime;
    const oscilador = audioContexto.createOscillator();
    oscilador.type = 'sine';
    oscilador.frequency.setValueAtTime(60, ahora);
    oscilador.frequency.exponentialRampToValueAtTime(30, ahora + 0.22);
    const ganancia = audioContexto.createGain();
    ganancia.gain.setValueAtTime(0.0001, ahora);
    ganancia.gain.exponentialRampToValueAtTime(0.8, ahora + 0.02);
    ganancia.gain.exponentialRampToValueAtTime(0.0001, ahora + 0.4);
    oscilador.connect(ganancia);
    ganancia.connect(gananciaMaestra);
    oscilador.start(ahora);
    oscilador.stop(ahora + 0.5);
  }, 950);
  intervalosAudio.push(intervalo);
}

function crearLluvia() {
  const fuente = audioContexto.createBufferSource();
  fuente.buffer = crearRuidoBlanco(4);
  fuente.loop = true;
  const filtro = audioContexto.createBiquadFilter();
  filtro.type = 'bandpass';
  filtro.frequency.value = 3200;
  filtro.Q.value = 0.6;
  const ganancia = audioContexto.createGain();
  ganancia.gain.value = 0.12;
  fuente.connect(filtro);
  filtro.connect(ganancia);
  ganancia.connect(gananciaMaestra);
  fuente.start();
  nodosAudio.push(fuente, filtro, ganancia);
}

function detenerNodos() {
  intervalosAudio.forEach(id => clearInterval(id));
  intervalosAudio = [];
  nodosAudio.forEach(nodo => {
    try { if (nodo.stop) nodo.stop(); } catch (e) {}
    try { nodo.disconnect(); } catch (e) {}
  });
  nodosAudio = [];
  gananciaMaestra = null;
}

function iniciarSonido() {
  if (!ajustesActuales) return;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return;
  if (!audioContexto) audioContexto = new AC();
  detenerNodos();
  crearGananciaMaestra();
  switch (ajustesActuales.sonido) {
    case 'viento': crearViento(); break;
    case 'zumbido': crearZumbido(); break;
    case 'latido': crearLatido(); break;
    case 'lluvia': crearLluvia(); break;
  }
  if (audioContexto.state === 'suspended') audioContexto.resume();
}

function detenerSonido() {
  if (!audioContexto) return;
  detenerNodos();
  audioContexto.suspend();
}

function cambiarVolumen() {
  if (gananciaMaestra) gananciaMaestra.gain.value = (ajustesActuales && ajustesActuales.volumen) || 0.3;
}
