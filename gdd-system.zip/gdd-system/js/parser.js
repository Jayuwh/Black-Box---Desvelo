function escaparHtml(texto) {
  return texto
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function hexARgba(hex, alfa) {
  const h = hex.replace('#', '');
  const bigint = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  const r = (bigint >> 16) & 255, g = (bigint >> 8) & 255, b = bigint & 255;
  return `rgba(${r}, ${g}, ${b}, ${alfa})`;
}

const EFECTOS = {
  glow: 'efecto-neon',
  gradient: 'efecto-degradado',
  flicker: 'efecto-parpadeo',
  underline: 'efecto-subrayado',
  contorno: 'efecto-contorno',
  sombra: 'efecto-sombra',
  marca: 'efecto-marca',
  onda: 'efecto-onda',
  arcoiris: 'efecto-arcoiris',
  temblor: 'efecto-temblor'
};

function renderizarVariable(clave, variables) {
  const v = variables[clave];
  if (!v) return `<span class="etiqueta-variable" style="color:var(--acento-verguenza)">[${escaparHtml(clave)}]</span>`;

  if (v.efecto === 'gradient') {
    const primero = v.color || '#c4456b';
    const segundo = v.colorSecundario || '#5487c9';
    const estilo = `background:linear-gradient(90deg,${primero},${segundo});-webkit-background-clip:text;background-clip:text;color:transparent;`;
    return `<span class="etiqueta-variable efecto-degradado" style="${estilo}">${escaparHtml(v.valor)}</span>`;
  }
  if (v.efecto === 'glow') {
    const estilo = `color:${v.color}; text-shadow: 0 0 10px ${hexARgba(v.color, 0.65)}, 0 0 22px ${hexARgba(v.color, 0.4)};`;
    return `<span class="etiqueta-variable" style="${estilo}">${escaparHtml(v.valor)}</span>`;
  }

  const clases = ['etiqueta-variable'];
  if (EFECTOS[v.efecto]) clases.push(EFECTOS[v.efecto]);
  return `<span class="${clases.join(' ')}" style="color:${v.color};">${escaparHtml(v.valor)}</span>`;
}

function renderizarEfecto(efecto, texto) {
  const clase = EFECTOS[efecto];
  if (!clase) return texto;
  if (efecto === 'glow') return `<span class="${clase}" style="color:var(--acento-verguenza)">${texto}</span>`;
  return `<span class="${clase}">${texto}</span>`;
}

function renderizarSeparador(tipo) {
  if (tipo === 'shame') return `<hr class="separador separador-verguenza">`;
  if (tipo === 'fracture') return `<div class="separador separador-fractura"></div>`;
  return `<hr class="separador separador-vacio">`;
}

function renderizarLinea(texto, variables) {
  let salida = escaparHtml(texto);

  salida = salida.replace(/\[([A-Z0-9_]+)\]/g, (m, clave) => renderizarVariable(clave, variables));

  salida = salida.replace(/\{\{(gradient|glow|flicker|underline|contorno|sombra|marca|onda|arcoiris|temblor):([^}]+)\}\}/g, (m, efecto, txt) =>
    renderizarEfecto(efecto, txt)
  );

  salida = salida.replace(/`([^`]+)`/g, '<code>$1</code>');

  salida = salida.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

  salida = salida.replace(/(^|[^*])\*([^*]+)\*(?!\*)/g, '$1<em>$2</em>');

  salida = salida.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');

  return salida;
}

function parsearMarkdown(origen, variables) {
  const lineas = origen.replace(/\r\n/g, '\n').split('\n');
  let html = '';
  let bufferLista = [];
  let tipoLista = null;
  let bufferCita = [];

  function vaciarLista() {
    if (bufferLista.length) {
      const etiqueta = tipoLista === 'ol' ? 'ol' : 'ul';
      html += `<${etiqueta}>${bufferLista.map(i => `<li>${renderizarLinea(i, variables)}</li>`).join('')}</${etiqueta}>`;
      bufferLista = [];
      tipoLista = null;
    }
  }

  function vaciarCita() {
    if (bufferCita.length) {
      html += `<blockquote>${bufferCita.map(l => renderizarLinea(l, variables)).join('<br>')}</blockquote>`;
      bufferCita = [];
    }
  }

  for (let linea of lineas) {
    const recortada = linea.trim();

    const coincidenciaSeparador = recortada.match(/^\*\*\*(void|shame|fracture)\*\*\*$/);
    if (coincidenciaSeparador) {
      vaciarLista(); vaciarCita();
      html += renderizarSeparador(coincidenciaSeparador[1]);
      continue;
    }

    if (recortada === '') { vaciarLista(); vaciarCita(); continue; }

    const encabezado3 = recortada.match(/^###\s+(.*)$/);
    const encabezado2 = recortada.match(/^##\s+(.*)$/);
    const encabezado1 = recortada.match(/^#\s+(.*)$/);
    const elementoLista = recortada.match(/^-\s+(.*)$/);
    const elementoListaOrd = recortada.match(/^\d+\.\s+(.*)$/);
    const cita = recortada.match(/^>\s?(.*)$/);

    if (encabezado1) { vaciarLista(); vaciarCita(); html += `<h1>${renderizarLinea(encabezado1[1], variables)}</h1>`; continue; }
    if (encabezado2) { vaciarLista(); vaciarCita(); html += `<h2>${renderizarLinea(encabezado2[1], variables)}</h2>`; continue; }
    if (encabezado3) { vaciarLista(); vaciarCita(); html += `<h3>${renderizarLinea(encabezado3[1], variables)}</h3>`; continue; }

    if (elementoLista) { vaciarCita(); tipoLista = 'ul'; bufferLista.push(elementoLista[1]); continue; }
    if (elementoListaOrd) { vaciarCita(); tipoLista = 'ol'; bufferLista.push(elementoListaOrd[1]); continue; }

    if (cita) { vaciarLista(); bufferCita.push(cita[1]); continue; }

    vaciarLista(); vaciarCita();
    html += `<p>${renderizarLinea(recortada, variables)}</p>`;
  }
  vaciarLista();
  vaciarCita();
  return html;
}
