/* Rompecabezas de percepción: piezas regadas por el documento, arrastrables,
   que al colocarse en su hueco correcto reconstruyen una nota. */

const RC_TAM_PIEZA = 60;
const RC_COLUMNAS = 3;
const RC_FILAS = 3;
const RC_TOTAL = RC_COLUMNAS * RC_FILAS;
const RC_LIENZO_TAM = RC_TAM_PIEZA * RC_COLUMNAS;
const RC_UMBRAL_ENCAJE = 42;

let rcContenedor = null;
let rcHuecos = [];
let rcPiezas = [];
let rcColocadas = 0;
let rcArrastrando = null;
let rcAutoScrollId = null;
let rcContador = null;

function rcCrearNotaDataUrl(inicialFirma) {
  const lienzo = document.createElement('canvas');
  lienzo.width = RC_LIENZO_TAM;
  lienzo.height = RC_LIENZO_TAM;
  const ctx = lienzo.getContext('2d');

  ctx.fillStyle = '#ece3d2';
  ctx.fillRect(0, 0, RC_LIENZO_TAM, RC_LIENZO_TAM);
  for (let i = 0; i < 900; i++) {
    ctx.fillStyle = `rgba(110,90,60,${Math.random() * 0.06})`;
    ctx.fillRect(Math.random() * RC_LIENZO_TAM, Math.random() * RC_LIENZO_TAM, 1, 1);
  }
  ctx.strokeStyle = 'rgba(0,0,0,.07)';
  ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(0, RC_LIENZO_TAM / 3); ctx.lineTo(RC_LIENZO_TAM, RC_LIENZO_TAM / 3); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(0, (RC_LIENZO_TAM / 3) * 2); ctx.lineTo(RC_LIENZO_TAM, (RC_LIENZO_TAM / 3) * 2); ctx.stroke();

  ctx.fillStyle = '#2c2a28';
  ctx.font = '22px cursive';
  ctx.textBaseline = 'top';
  const lineas = ['Perdón por lo de', 'esta mañana.', '', 'No sé cómo quedarme', 'cuando duele.', '', `— ${inicialFirma || 'A'}.`];
  lineas.forEach((linea, i) => ctx.fillText(linea, 22, 16 + i * 26));

  return lienzo.toDataURL();
}

function rcMezclar(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function rcCalcularHuecos() {
  const alto = rcContenedor.scrollHeight;
  const ancho = rcContenedor.clientWidth;
  const fraccionesY = [0.07, 0.17, 0.27, 0.39, 0.51, 0.63, 0.75, 0.85, 0.94];
  const fraccionesX = [0.05, 0.82, 0.08, 0.78, 0.46, 0.06, 0.8, 0.12, 0.74];
  return fraccionesY.map((fy, i) => ({
    top: Math.round(fy * alto),
    left: Math.round(Math.min(ancho - RC_TAM_PIEZA - 6, Math.max(6, fraccionesX[i] * ancho))),
  }));
}

function rcPosicionesInicialesPiezas(huecos) {
  let permutacion;
  do {
    permutacion = rcMezclar([...Array(RC_TOTAL).keys()]);
  } while (permutacion.some((v, i) => v === i));
  return permutacion.map((origenIdx) => {
    const base = huecos[origenIdx];
    const jitterX = (Math.random() - 0.5) * 30;
    const jitterY = (Math.random() - 0.5) * 30;
    return { top: base.top + jitterY, left: base.left + jitterX };
  });
}

function rcActualizarContador() {
  if (!rcContador) return;
  rcContador.textContent = `Nota: ${rcColocadas} / ${RC_TOTAL}`;
  rcContador.classList.toggle('completo', rcColocadas === RC_TOTAL);
}

function rcAlResolver() {
  rcPiezas.forEach((p) => p.el.classList.add('colocada'));
  document.dispatchEvent(new CustomEvent('rompecabezas:resuelto'));
}

function rcIntentarEncajar(pieza) {
  const hueco = rcHuecos[pieza.indice];
  const rectPieza = pieza.el.getBoundingClientRect();
  const rectHueco = hueco.el.getBoundingClientRect();
  const dx = (rectPieza.left + rectPieza.width / 2) - (rectHueco.left + rectHueco.width / 2);
  const dy = (rectPieza.top + rectPieza.height / 2) - (rectHueco.top + rectHueco.height / 2);
  if (Math.hypot(dx, dy) < RC_UMBRAL_ENCAJE) {
    pieza.el.style.left = hueco.left + 'px';
    pieza.el.style.top = hueco.top + 'px';
    pieza.el.classList.add('colocada');
    pieza.colocada = true;
    rcColocadas++;
    rcActualizarContador();
    if (rcColocadas === RC_TOTAL) rcAlResolver();
  }
}

function rcPosicionarDesdeEvento(pieza, clientX, clientY) {
  const rectContenedor = rcContenedor.getBoundingClientRect();
  const x = clientX - rectContenedor.left - pieza.dx;
  const y = clientY - rectContenedor.top - pieza.dy;
  pieza.el.style.left = x + 'px';
  pieza.el.style.top = y + 'px';
}

function rcBucleAutoScroll() {
  if (rcArrastrando) {
    const margen = 70;
    const y = rcArrastrando.ultimoY;
    if (y !== null) {
      if (y < margen) window.scrollBy(0, -8);
      else if (y > window.innerHeight - margen) window.scrollBy(0, 8);
    }
    rcPosicionarDesdeEvento(rcArrastrando, rcArrastrando.ultimoX, rcArrastrando.ultimoY);
    rcAutoScrollId = requestAnimationFrame(rcBucleAutoScroll);
  } else {
    rcAutoScrollId = null;
  }
}

function rcAlPointerDown(e, pieza) {
  if (pieza.colocada) return;
  e.preventDefault();
  pieza.el.setPointerCapture(e.pointerId);
  const rect = pieza.el.getBoundingClientRect();
  pieza.dx = e.clientX - rect.left;
  pieza.dy = e.clientY - rect.top;
  pieza.ultimoX = e.clientX;
  pieza.ultimoY = e.clientY;
  pieza.el.classList.add('arrastrando');
  rcArrastrando = pieza;
  if (!rcAutoScrollId) rcAutoScrollId = requestAnimationFrame(rcBucleAutoScroll);
}

function rcAlPointerMove(e) {
  if (!rcArrastrando) return;
  rcArrastrando.ultimoX = e.clientX;
  rcArrastrando.ultimoY = e.clientY;
  rcPosicionarDesdeEvento(rcArrastrando, e.clientX, e.clientY);
}

function rcAlPointerUp(e) {
  if (!rcArrastrando) return;
  const pieza = rcArrastrando;
  pieza.el.classList.remove('arrastrando');
  try { pieza.el.releasePointerCapture(e.pointerId); } catch (err) {}
  rcIntentarEncajar(pieza);
  rcArrastrando = null;
}

function rcConstruir(notaDataUrl) {
  rcHuecos.forEach((h) => h.el.remove());
  rcPiezas.forEach((p) => p.el.remove());
  rcHuecos = [];
  rcPiezas = [];
  rcColocadas = 0;

  const posicionesHueco = rcCalcularHuecos();
  const posicionesInicio = rcPosicionesInicialesPiezas(posicionesHueco);

  posicionesHueco.forEach((pos, i) => {
    const el = document.createElement('div');
    el.className = 'hueco-rompecabezas';
    el.style.top = pos.top + 'px';
    el.style.left = pos.left + 'px';
    rcContenedor.appendChild(el);
    rcHuecos.push({ el, top: pos.top, left: pos.left });
  });

  for (let i = 0; i < RC_TOTAL; i++) {
    const col = i % RC_COLUMNAS;
    const fila = Math.floor(i / RC_COLUMNAS);
    const el = document.createElement('div');
    el.className = 'pieza-rompecabezas';
    el.style.top = posicionesInicio[i].top + 'px';
    el.style.left = posicionesInicio[i].left + 'px';
    el.style.backgroundImage = `url(${notaDataUrl})`;
    el.style.backgroundPosition = `-${col * RC_TAM_PIEZA}px -${fila * RC_TAM_PIEZA}px`;
    rcContenedor.appendChild(el);

    const pieza = { el, indice: i, colocada: false, dx: 0, dy: 0, ultimoX: null, ultimoY: null };
    el.addEventListener('pointerdown', (e) => rcAlPointerDown(e, pieza));
    rcPiezas.push(pieza);
  }

  rcActualizarContador();
}

function rcReiniciar() {
  const inicial = (window.RC_INICIAL_FIRMA) || 'A';
  rcConstruir(rcCrearNotaDataUrl(inicial));
}

function inicializarRompecabezas(contenedor, inicialFirma) {
  rcContenedor = contenedor;
  window.RC_INICIAL_FIRMA = inicialFirma;
  if (getComputedStyle(rcContenedor).position === 'static') {
    rcContenedor.style.position = 'relative';
  }

  if (!rcContador) {
    rcContador = document.createElement('button');
    rcContador.className = 'contador-rompecabezas';
    rcContador.title = 'Volver a revolver la nota';
    rcContador.addEventListener('click', rcReiniciar);
    document.body.appendChild(rcContador);
  }

  if (!window.RC_LISTENERS_LISTOS) {
    window.addEventListener('pointermove', rcAlPointerMove);
    window.addEventListener('pointerup', rcAlPointerUp);
    window.addEventListener('pointercancel', rcAlPointerUp);
    window.RC_LISTENERS_LISTOS = true;
  }

  rcConstruir(rcCrearNotaDataUrl(inicialFirma));
}
