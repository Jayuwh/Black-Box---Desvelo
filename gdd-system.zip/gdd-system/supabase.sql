create table if not exists public.documento (
  id text primary key,
  markdown text not null default '',
  variables jsonb not null default '{}'::jsonb,
  ajustes jsonb not null default '{}'::jsonb,
  actualizado_en timestamptz not null default now()
);

alter table public.documento enable row level security;

drop policy if exists "lectura anonima" on public.documento;
create policy "lectura anonima" on public.documento
  for select using (true);

drop policy if exists "insercion anonima" on public.documento;
create policy "insercion anonima" on public.documento
  for insert with check (true);

drop policy if exists "actualizacion anonima" on public.documento;
create policy "actualizacion anonima" on public.documento
  for update using (true) with check (true);
